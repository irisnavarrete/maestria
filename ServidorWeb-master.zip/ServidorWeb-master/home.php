<html>
 <head>
  <title>Iris & Alan</title>
 </head>
 <body>
 <?php echo '<p>Bienvenido</p>'; ?>
 </body>
 <form action='destruir_sesion.php'>
    <input type="submit" name="sesionDestroy" value="Cerrar sesion"/>
</form>
</html>