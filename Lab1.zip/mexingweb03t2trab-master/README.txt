Descripción del sitio

Este sitio reune la información técnica de diversos elementos de hardware, tanto información técnica como manuales de usuario.
Se encuentra protegido por usuario y contraseña que da acceso a un menú de donde se puede consultar el catálogo de Hardware, así como el de usuarios registrados, y es posible registrar usuarios.
También se cuenta con una opción para salir y cerrar la sesión.

