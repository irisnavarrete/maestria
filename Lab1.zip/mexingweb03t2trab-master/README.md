# mexingweb03t2trab
Trabajo: Desarrollo web avanzado para la Maestría en Ingeniería de Software y Sistemas Informáticos 
Clase Computación en el Servidor Web

Descripción del trabajo

En esta actividad se propone desarrollar una página web en PHP de temática libre. El desarrollo se hará poniendo en práctica los conceptos estudiados en los dos primeros temas. Por tanto, los requisitos mínimos serían los siguientes:

»	Una estructura de control de cada tipo que hemos estudiado.
»	Una función.
»	Un array o matriz.
»	Uso de alguna función de cadenas (ver apartado 2.5 del Tema 2).

Como se indica, la temática será libre. No obstante, se valorará positivamente la usabilidad de la página web. También sería interesante que sea pensada para ser extendida posteriormente con el resto de los conceptos que se vayan estudiando en la asignatura.

Para realizar el desarrollo de la web, se puede utilizar un editor de texto, preferentemente, con resaltado sintáctico.

Entrega del trabajo 

Se deberá entregar un máximo de dos ficheros en los que se incluya el código que implementa los requisitos indicados en el enunciado. También se debe incluir una captura de pantalla del resultado de la página web desarrollada, visto en el navegador.

Integrantes del equipo:

José Daniel Sustaita Garza

Juan Carlos Valencia Lizardi

